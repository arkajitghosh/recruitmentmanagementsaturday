package com.cg.rms.dto;

public class CandidateQualifications {
	String qualification_id;
	String qualification_name;
	String specialization_area;
    String college_name;
    String university_name;
    String year_of_passing;
    String percentage;
    String candidate_id;
    public CandidateQualifications(){}
	public String getQualification_id() {
		return qualification_id;
	}
	public void setQualification_id(String qualification_id) {
		this.qualification_id = qualification_id;
	}
	public String getQualification_name() {
		return qualification_name;
	}
	public void setQualification_name(String qualification_name) {
		this.qualification_name = qualification_name;
	}
	public String getSpecialization_area() {
		return specialization_area;
	}
	public void setSpecialization_area(String specialization_area) {
		this.specialization_area = specialization_area;
	}
	public String getCollege_name() {
		return college_name;
	}
	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}
	public String getUniversity_name() {
		return university_name;
	}
	public void setUniversity_name(String university_name) {
		this.university_name = university_name;
	}
	public String getYear_of_passing() {
		return year_of_passing;
	}
	public void setYear_of_passing(String year_of_passing) {
		this.year_of_passing = year_of_passing;
	}
	public String getPercentage() {
		return percentage;
	}
	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}
	public String getCandidate_id() {
		return candidate_id;
	}
	public void setCandidate_id(String candidate_id) {
		this.candidate_id = candidate_id;
	}
	@Override
	public String toString() {
		return "CandidateQualifications [qualification_id=" + qualification_id
				+ ", qualification_name=" + qualification_name
				+ ", specialization_area=" + specialization_area
				+ ", college_name=" + college_name + ", university_name="
				+ university_name + ", year_of_passing=" + year_of_passing
				+ ", percentage=" + percentage + ", candidate_id="
				+ candidate_id + "]";
	}
}