package com.cg.rms.dao;

import java.util.List;

import com.cg.rms.dto.CandidateQualifications;
import com.cg.rms.dto.CandidateWorkHistory;
import com.cg.rms.exceptions.CandidateQualificationsException;


public interface CandidateQualificationsDAO {
	public String addCandidateQualifications(CandidateQualifications c) throws CandidateQualificationsException;
	List<CandidateQualifications> getAllQualifications() throws CandidateQualificationsException;
	public boolean updateCandidateQualifications(CandidateQualifications cqualifications) throws CandidateQualificationsException;
	List<CandidateQualifications> searchjobs(String jreq) throws CandidateQualificationsException;
	List<CandidateWorkHistory> searchjobs2(String jreq)	throws CandidateQualificationsException;
	

}
