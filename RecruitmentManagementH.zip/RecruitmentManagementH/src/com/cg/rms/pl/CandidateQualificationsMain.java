package com.cg.rms.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.rms.dto.CandidateQualifications;
import com.cg.rms.dto.CandidateWorkHistory;
import com.cg.rms.exceptions.CandidateQualificationsException;
import com.cg.rms.service.CandidateQualificationsService;
import com.cg.rms.service.CandidateQualificationsServiceImpl;
public class CandidateQualificationsMain {
	static CandidateQualifications c = new CandidateQualifications();
	static CandidateWorkHistory cwh= new CandidateWorkHistory();
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		CandidateQualificationsService cser = new CandidateQualificationsServiceImpl();
do {
System.out.println("menu");
System.out.println("1. show all candidate Qualification details");
System.out.println("2. Add new candidate Qualification Details");
/*System.out.println("3. delete a course");*/
System.out.println("3. update candidate Qualification Details");
System.out.println("4. search candidate details based on qualifications");
System.out.println("5. exit");
int choice = sc.nextInt();
switch (choice) {
case 1:
	try {
		List<CandidateQualifications> clist =  cser.getAllQualifications();
		for (CandidateQualifications c:clist) {
			System.out.println(c);
			
		}
	} catch (CandidateQualificationsException e) {
		System.err.println(e.getMessage());
		
		//e.printStackTrace();
	}
	break;
case 2:
	
	System.out.println("enter qualification name");
    c.setQualification_name(sc.next());
	System.out.println("enter specialization area");
	c.setSpecialization_area(sc.next());
	System.out.println("enter college name");
	c.setCollege_name(sc.next());
	System.out.println("Enter university name");
	c.setUniversity_name(sc.next());
	System.out.println("enter year of passing");
	c.setYear_of_passing(sc.next());
	System.out.println("enter percentage");
	c.setPercentage(sc.next());
	
    
    String cid;
	try {
		cid = cser.addCandidateQualifications(c);
		System.out.println("qualifications added with ID"+cid);
	} catch (CandidateQualificationsException e1) {
		// TODO Auto-generated catch block
		e1.printStackTrace();
	}
	
	break;

case 3:
	System.out.println("enter the qualification  Id to update the details ");
	
	try {
		boolean b = cser.updateCandidateQualifications(c);
		if(b) {
			System.out.println("Details updated s");
		}
	} catch (CandidateQualificationsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	break;
case 4:
	
	System.out.println("Enter the qualifications to search candidate details ");
	c.setQualification_name(sc.next());
	System.out.println("Enter the position to search candidate details ");
	cwh.setPosition_held(sc.next());
	try {
		List<CandidateQualifications> jlist = cser.searchjobs(c.getQualification_name());
		if(jlist!=null) {
			for (CandidateQualifications j:jlist) {
				
				System.out.println(j);
				
			}
			System.out.println("Search1 Completed");
			List<CandidateWorkHistory> jlist2 = cser.searchjobs2(cwh.getPosition_held());
			if(jlist2!=null) {
				for (CandidateWorkHistory j2:jlist2) {
					System.out.println(j2);
					
				}
				System.out.println("Search2 Completed");
				
			
		}
		}
		
	} catch (CandidateQualificationsException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	break;
	
case 5: System.exit(0);

default:System.out.println("invalid choice");
	
	break;
}
} while (true);
	
	}

	private void setQ(String next) {
		// TODO Auto-generated method stub
		
	}
}




		
			
			
			
			
			
				